import os, sqlite3, json, csv, io, re
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse

DB=Path(os.environ.get('DB_PATH','data/vsiaf.sqlite3')); DB.parent.mkdir(parents=True,exist_ok=True)
SCHEMA={'activos':['codigo','nombre','grupo','oficina','responsable','fecha','valor','estado'],'grupos':['codigo','nombre','auxiliar'],'oficinas':['codigo','nombre','responsable'],'administradores':['codigo','nombre','rol'],'unidad':['codigo','nombre','entidad']}
REQUIRED={'activos':['codigo','nombre','grupo','oficina','fecha','valor','estado'],'grupos':['codigo','nombre'],'oficinas':['codigo','nombre'],'administradores':['codigo','nombre','rol'],'unidad':['codigo','nombre','entidad']}
def connect():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
with connect() as c:
 for t,cols in SCHEMA.items():
  c.execute('CREATE TABLE IF NOT EXISTS '+t+' (id INTEGER PRIMARY KEY, '+', '.join(k+' TEXT NOT NULL DEFAULT \'\'' for k in cols)+', UNIQUE(codigo))')
def validate(t,d,c):
 if not isinstance(d,dict): raise ValueError('Registro inválido')
 d={k:str(d.get(k,'')).strip() for k in SCHEMA[t]}
 for k in REQUIRED[t]:
  if not d[k]: raise ValueError('Campo obligatorio: '+k)
 if any(len(v)>250 for v in d.values()): raise ValueError('Campo demasiado largo')
 if t=='activos':
  from decimal import Decimal,InvalidOperation
  from datetime import date
  try:
   n=Decimal(d['valor']); assert n.is_finite() and n>=0; date.fromisoformat(d['fecha'])
  except (InvalidOperation,ValueError,AssertionError): raise ValueError('Fecha o valor inválido')
  if d['estado'] not in ('Bueno','Regular','Malo','Baja'): raise ValueError('Estado inválido')
  for field,table in [('grupo','grupos'),('oficina','oficinas')]:
   if not c.execute('SELECT 1 FROM '+table+' WHERE codigo=?',(d[field],)).fetchone(): raise ValueError('No existe '+field+' con ese código')
 return d
class Handler(BaseHTTPRequestHandler):
 def send(self,status,data,typ='application/json; charset=utf-8',filename=None):
  b=data if isinstance(data,bytes) else (json.dumps(data,ensure_ascii=False).encode() if typ.startswith('application/json') else data.encode())
  self.send_response(status); self.send_header('Content-Type',typ); self.send_header('Content-Length',str(len(b))); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'")
  if filename: self.send_header('Content-Disposition','attachment; filename="'+filename+'"')
  self.end_headers(); self.wfile.write(b)
 def do_GET(self): self.handle_api('GET')
 def do_POST(self): self.handle_api('POST')
 def do_PUT(self): self.handle_api('PUT')
 def do_DELETE(self): self.handle_api('DELETE')
 def handle_api(self,method):
  path=urlparse(self.path).path
  if method=='GET' and path in ('/','/login'):
   return self.send(200,Path(__file__).with_name('index.html').read_bytes(),'text/html; charset=utf-8')
  if method=='GET' and path=='/health': return self.send(200,{'ok':True})
  try:
   with connect() as c:
    if method=='GET' and path=='/api/backup':
     return self.send(200,{t:[dict(r) for r in c.execute('SELECT * FROM '+t)] for t in SCHEMA},filename='respaldo-demo.json')
    if method=='GET' and path=='/api/report':
     f=io.StringIO(); w=csv.writer(f); cols=SCHEMA['activos']; w.writerow(cols)
     for r in c.execute('SELECT * FROM activos ORDER BY codigo'):
      w.writerow([("'"+r[k]) if r[k].startswith(('=','+','-','@','\t','\r')) else r[k] for k in cols])
     return self.send(200,'\ufeff'+f.getvalue(),'text/csv; charset=utf-8','activos-demo.csv')
    match=re.fullmatch(r'/api/(\w+)(?:/(\d+))?',path)
    if not match or match[1] not in SCHEMA: return self.send(404,{'error':'Ruta no disponible'})
    t=match[1]; ident=match[2]; cols=SCHEMA[t]
    if method=='GET' and not ident: return self.send(200,[dict(r) for r in c.execute('SELECT * FROM '+t+' ORDER BY codigo')])
    if method in ('POST','PUT'):
     n=int(self.headers.get('Content-Length',0));
     if n>100000: raise ValueError('Solicitud demasiado grande')
     d=validate(t,json.loads(self.rfile.read(n)),c)
     if method=='POST' and not ident:
      cur=c.execute('INSERT INTO '+t+' ('+','.join(cols)+') VALUES ('+','.join('?' for k in cols)+')',list(d.values())); return self.send(201,{'id':cur.lastrowid})
     if method=='PUT' and ident:
      old=c.execute('SELECT * FROM '+t+' WHERE id=?',(ident,)).fetchone()
      if not old: return self.send(404,{'error':'Registro no encontrado'})
      if t in ('grupos','oficinas') and old['codigo']!=d['codigo']:
       field='grupo' if t=='grupos' else 'oficina'
       if c.execute('SELECT 1 FROM activos WHERE '+field+'=?',(old['codigo'],)).fetchone(): raise ValueError('Código utilizado por un activo')
      c.execute('UPDATE '+t+' SET '+','.join(k+'=?' for k in cols)+' WHERE id=?',list(d.values())+[ident]); return self.send(200,{'ok':True})
    if method=='DELETE' and ident:
     old=c.execute('SELECT * FROM '+t+' WHERE id=?',(ident,)).fetchone()
     if not old: return self.send(404,{'error':'Registro no encontrado'})
     if t in ('grupos','oficinas'):
      field='grupo' if t=='grupos' else 'oficina'
      if c.execute('SELECT 1 FROM activos WHERE '+field+'=?',(old['codigo'],)).fetchone(): raise ValueError('Registro asociado a un activo')
     c.execute('DELETE FROM '+t+' WHERE id=?',(ident,)); return self.send(200,{'ok':True})
    return self.send(405,{'error':'Operación no admitida'})
  except sqlite3.IntegrityError: return self.send(409,{'error':'Código duplicado'})
  except (ValueError,TypeError): return self.send(400,{'error':str(__import__('sys').exc_info()[1])})
  except Exception: return self.send(500,{'error':'Error interno de la demostración'})
if __name__=='__main__': ThreadingHTTPServer(('0.0.0.0',int(os.environ.get('PORT','8000'))),Handler).serve_forever()
