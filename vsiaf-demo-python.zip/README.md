# Sistema de activos fijos — demostración independiente

Prototipo no oficial basado únicamente en la estructura pública de menús de la referencia vSIAF. No se conecta al sistema institucional ni reutiliza código o logotipos oficiales. Usa exclusivamente datos ficticios. **No introduzcas credenciales reales ni datos personales o institucionales.**

## Requisitos
- Python 3.10 o superior.
- No requiere instalar paquetes externos.

## Ejecutar en IntelliJ IDEA
1. Extrae el ZIP.
2. Abre IntelliJ IDEA y selecciona **Open**; elige la carpeta `vsiaf-demo-ready`.
3. Configura un intérprete Python 3.10 o superior (si tu edición/plugin lo admite).
4. Abre `app.py` y ejecútalo; alternativamente, abre la terminal integrada y ejecuta `python app.py`.
5. Entra en `http://localhost:8000`.

## Ejecutar en Visual Studio Code
1. Extrae el ZIP y abre la carpeta con **File > Open Folder**.
2. Instala la extensión Python de Microsoft si aún no está instalada.
3. Selecciona un intérprete Python 3.10 o superior.
4. Pulsa `F5` y elige **Ejecutar vSIAF demo**, o ejecuta `python app.py` en la terminal.
5. Entra en `http://localhost:8000`.

## Ejecutar desde terminal
```bash
python app.py
```
En algunos equipos se utiliza `python3 app.py`. La base SQLite se crea automáticamente en `data/vsiaf.sqlite3`.

## Publicar en Render
Crear un repositorio GitHub propio y subir el contenido de esta carpeta. En Render, crear un **Web Service** conectado a ese repositorio con:
- Runtime: Python
- Build command: `python --version`
- Start command: `python app.py`
- Health check path: `/health`

El servicio gratuito puede perder la base SQLite al reiniciarse o desplegarse. Para datos persistentes se requiere un disco persistente compatible o migrar a PostgreSQL. Esta demostración no debe utilizarse con datos reales.

## Alcance de esta demostración
Incluye CRUD de activos, grupos, oficinas, administradores de referencia y unidad; búsqueda; validación básica de campos, códigos duplicados y referencias; exportación CSV y descarga de respaldo JSON. No incluye autenticación ni permisos reales, restauración de respaldos, depreciaciones, historial de movimientos, reportes oficiales ni todas las reglas del vSIAF institucional. Los módulos son una demostración y no una réplica exacta certificada.
